import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-jumbo-details',
  templateUrl: './jumbo-details.component.html',
  styleUrls: ['./jumbo-details.component.css']
})
export class JumboDetailsComponent implements OnInit {

  constructor() { 
    console.log('d')
    document.querySelector('.jumbotron').classList.add('d-none');
  }
  ngOnInit() {
  }

/*  if((document.location).search == "/jumbo-Details") {
  }
*/
}
