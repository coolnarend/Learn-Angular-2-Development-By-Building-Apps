import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { CookieService } from 'angular2-cookie/core';
import { Ng2Webstorage } from 'ngx-webstorage';

import { AppComponent } from './app.component';

@NgModule({
  declarations: [
    AppComponent
  ],
  imports: [
    BrowserModule,
    Ng2Webstorage
  ],
  providers: [CookieService],
  bootstrap: [AppComponent]
})
export class AppModule { }
