import { Component } from '@angular/core';
import { CookieService } from 'angular2-cookie/core';
import { LocalStorageService, SessionStorageService } from 'ngx-webstorage';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'app';

  constructor(
    private _cookieService: CookieService,
    private sessionSt: SessionStorageService,
    private localSt: LocalStorageService,
  ) {}

  setCookies() {
    this._cookieService.put('test', 'testing cookie');
  }
  getCookies() {
    alert(this._cookieService.get('test'));
  }
  delCookies() {
    this._cookieService.remove('test');
  }

  setLocalStorage() {
    this.localSt.store('userName', 'testing local storage');
  }
  getLocalStorage() {
    alert(this.localSt.retrieve('userName'));
  }
  delLocalStorage() {
    this.localSt.clear('userName');
  }

  setSessionStorage() {
    this.sessionSt.store('logged-in', 'testing session storage');
  }
  getSessionStorage() {
    alert(this.sessionSt.retrieve('logged-in'));
  }
  delSessionStorage() {
    this.sessionSt.clear('logged-in');
  }

}
