import {
  NgModule,
  Component,
  OnInit,
  ViewChild
} from '@angular/core';
import {Signup} from '../shared/signup';
/*
import { FormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
*/
@Component({
  selector: 'app-template-form',
  templateUrl: './template-form.component.html',
  styleUrls: ['./template-form.component.css']
})
export class TemplateFormComponent implements OnInit {

  private flag = false;
  public model: Signup = new Signup();

  @ViewChild('f') form: any;
  // public signUp: Signup;

  langs: string[] = [
    'English',
    'French',
    'German',
  ];

  constructor() { }

  ngOnInit() { }

  loadMyChildComponent() {
    this.flag = !this.flag;
  }

  onSubmit() {
    if (this.form.valid) {
      console.log('Form Submitted');
      this.form.reset();
    }
  }

}
