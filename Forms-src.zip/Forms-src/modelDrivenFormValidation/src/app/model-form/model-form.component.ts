import { NgModule, Component, OnInit } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';

import { FormGroup, FormControl, Validators } from '@angular/forms';
/*
import { ReactiveFormsModule } from '@angular/forms';
      import {
        ReactiveFormsModule,
        FormsModule,
        FormGroup,
        FormControl,
        Validators,
        FormBuilder
      } from '@angular/forms';
*/
@Component({
  selector: 'app-model-form',
  templateUrl: './model-form.component.html',
  styleUrls: ['./model-form.component.css']
})
export class ModelFormComponent implements OnInit {

  private flag = false;

  myForm: FormGroup;

  langs: string[] = [
    'English', 'French', 'German'
  ];

  // constructor(private fb: FormBuilder) { }
  constructor() { }

  ngOnInit() {
    this.myForm = new FormGroup({
      name: new FormGroup({
        firstname: new FormControl('', Validators.required),
        lastname: new FormControl('', Validators.required)
      }),
      email: new FormControl('', [
        Validators.required,
        Validators.pattern('[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$')
      ]),
      password: new FormControl('', [
        Validators.required,
        Validators.minLength(8)
      ]),
      language: new FormControl()
    });
    /*
    const a = this.myForm.controls.email.dirty;
    const b = this.myForm.controls.email.pristine;
    const c = this.myForm.controls.email.touched;
    console.log('myform', a, b, c);
    */
  }
/*
  ngOnInit() {
    this.myForm = this.fb.group({
      name: this.fb.group({
        firstname: ['', Validators.required],
        lastname: ['', Validators.required]
      }),
      localEmailVar: ['', [
        Validators.required,
        Validators.pattern('[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$')
      ]],
      password: ['', [
        Validators.required,
        Validators.minLength(8)
      ]],
      language: []
    });
  }
*/


  loadMyChildComponent() {
    this.flag = !this.flag;
  }

}
