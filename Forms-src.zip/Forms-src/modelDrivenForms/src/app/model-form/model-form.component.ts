import { NgModule, Component, OnInit } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { FormGroup, FormControl } from '@angular/forms';

@Component({
  selector: 'app-model-form',
  templateUrl: './model-form.component.html',
  styleUrls: ['./model-form.component.css']
})
export class ModelFormComponent implements OnInit {

  private flag = false;

  myForm: FormGroup;

  langs: string[] = [
    'English', 'French', 'German'
  ];

  constructor() { }

  ngOnInit() {
    this.myForm = new FormGroup({
      name: new FormGroup({
        firstname: new FormControl(),
        lastname: new FormControl()
      }),
      localEmailVar: new FormControl(),
      password: new FormControl(),
      language: new FormControl()
    });
  }

  loadMyChildComponent() {
    this.flag = !this.flag;
  }

}
