import { Component, OnInit, EventEmitter } from '@angular/core';
import { FormControl } from '@angular/forms';

import 'rxjs/add/operator/debounceTime.js';
import 'rxjs/add/operator/distinctUntilChanged';

// OR
// import 'rxjs/Rx';

@Component({
  selector: 'app-reactive-model-form',
  templateUrl: './reactive-model-form.component.html',
  styleUrls: ['./reactive-model-form.component.css']
})
export class ReactiveModelFormComponent implements OnInit {

  private flag = false;
  searchField: FormControl;
  searches: string[] = [];

  constructor() { }

  ngOnInit() {
    this.searchField = new FormControl();
    this.searchField.valueChanges
        .debounceTime(900)
        .distinctUntilChanged()
        .subscribe(term => {
          this.searches.push(term);
        });
  }

  loadMyChildComponent() {
    this.flag = !this.flag;
  }

}
